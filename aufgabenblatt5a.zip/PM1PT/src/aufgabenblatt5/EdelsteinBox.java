package aufgabenblatt5;

/**
 * Klasse EdelsteinBox beinhaltet den Aufzaehlungstyp Edelstein und speichert
 * diese in einem Array ab.
 * 
 * @author Andre
 *
 */
public class EdelsteinBox {
	/**
	 * Aufzaehlung vom Typ Edelstein, beinhaltet Diamant, Rubin und Smaragd.
	 * 
	 * @author Andre
	 *
	 */
	private enum Edelsteine {
		DIAMANT, RUBIN, SMARAGD
	}

	/**
	 * Array, in dem die Edelsteine abgelegt werden.
	 */
	private int[] inhalt;

	public EdelsteinBox(Edelsteine... inhalt) {
		this.inhalt = new int[Edelsteine.values().length];
		for(Edelsteine sorte: inhalt){
			this.inhalt[sorte.ordinal()]++;
		}
	}

	/**
	 * Liefert die Anzahl an enthaltenen Edelsteinen der uerbergebenen Sorte
	 * 
	 * @param sorte
	 * @return
	 */
	public int getAnzahl(Edelsteine sorte) {
		return inhalt[sorte.ordinal()];
	}

	/**
	 * Gibt auf der Konsole eine Zeile mit einer Textdarstellung dieses
	 * Schatzkaestchens aus.
	 * 
	 * F�r jeden Diamanten wird ein D gedruckt, f�r jeden Rubin ein R und f�r
	 * jeden Smaragden ein S. Alle Buchstaben folgen lueckenlos aufeinander. Die
	 * Buchstabenfolge wird in runde Klammern gesetzt. Ein Schatzk�stchen mit 1
	 * Diamanten, 2 Rubinen und 3 Smaragden wird zum Beispiel ausgegeben als
	 * (DRRSSS)
	 * 
	 */
	public String toString() {
		String name = "(";

		for (int i = 0; i < getAnzahl(Edelsteine.DIAMANT); i++) {
			name += "D";
		}
		for (int i = 0; i < getAnzahl(Edelsteine.RUBIN); i++) {
			name += "R";
		}
		for (int i = 0; i < getAnzahl(Edelsteine.SMARAGD); i++) {
			name += "S";
		}

		name += ")";
		return name;
	}

	/**
	 * Fuegt diesem Schatzkaestchen eine beliebige Anzahl von Edelsteine einer
	 * beliebigen Sorte hinzu.
	 * 
	 */
	public EdelsteinBox hineinlegen(Edelsteine sorte, int n) {
		inhalt[sorte.ordinal()] += n;
		return this;
	}

	/**
	 * Entnimmt diesem Schatzkaestchen eine beliebige Anzahl Edelsteine der
	 * angegebenen Sorte. Wenn weniger als n Edelsteine der Sorte enthalten
	 * sind, werden alle entnommen.
	 * 
	 * @param sorte
	 *            Sorte der zu entnehmenden Edelsteine
	 * @param n
	 *            Anzahl der zu entnehmenden Edelsteine
	 */
	public EdelsteinBox herausnehmen(Edelsteine sorte, int n) {
		if (inhalt[sorte.ordinal()] >= n) {
			inhalt[sorte.ordinal()] -= n;
		}
		else {
			inhalt[sorte.ordinal()] = 0;
		}
		return this;
	}

	/**
	 * Wandelt alle Edelsteine der Sorte vonSorte in Edelsteine der Sorte
	 * zuSorte um.
	 * 
	 * @param vonSorte
	 * @param zuSorte
	 */
	public EdelsteinBox umwandeln(Edelsteine vonSorte, Edelsteine zuSorte) {
		inhalt[zuSorte.ordinal()] += inhalt[vonSorte.ordinal()];
		inhalt[vonSorte.ordinal()] = 0;
		return this;
	}

	/**
	 * Entleert dieses Schatzkaestchen. Es enthaelt dann keine Edelsteine mehr.
	 * 
	 */
	public EdelsteinBox leeren() {
		inhalt = new int[3];
		return this;
	}

	public static void main(String[] args) {
		EdelsteinBox edelsteinBox = new EdelsteinBox(Edelsteine.DIAMANT, Edelsteine.DIAMANT, Edelsteine.RUBIN, Edelsteine.SMARAGD);
		System.out.println(edelsteinBox);
		System.out.println(edelsteinBox.hineinlegen(Edelsteine.RUBIN, 4));
		System.out.println(edelsteinBox.herausnehmen(Edelsteine.RUBIN, 2));
		System.out.println(edelsteinBox.umwandeln(Edelsteine.RUBIN, Edelsteine.SMARAGD));
		System.out.println("Smaragde: " + edelsteinBox.getAnzahl(Edelsteine.SMARAGD));
		System.out.println(edelsteinBox.leeren());
	}
}
