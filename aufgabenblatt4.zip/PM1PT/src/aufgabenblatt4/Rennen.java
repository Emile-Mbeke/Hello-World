/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 4, Aufgabe 2
* Verwendete Quellen:--
*/

package aufgabenblatt4;

import java.util.Scanner;

/**
 * Fuehrt ein Rennen mit Objekten des Typs Rennauto aus.
 * 
 * @author Andre Brand
 *
 */
public class Rennen {
	private int anzahlAutos;
	private double streckenlaenge;
	public Rennauto sieger;
	private Rennauto[] rennautos;
	
	Rennen(){
		
	}

	Rennen(String fahrername, String fahrzeugtyp, double maximalgeschwindigkeit) {
		rennautos = new Rennauto[1];
		rennautos[0] = new Rennauto(fahrername, fahrzeugtyp, maximalgeschwindigkeit);
		anzahlAutos = rennautos.length;
	}

	public double setStreckenlaenge(Scanner scanner) {
		System.out.println("Wie lang soll die Strecke sein? (Angabe in Kilometer)");
		return streckenlaenge = scanner.nextDouble();
	}
	
	public int getAnzahlAutos(){
		return anzahlAutos;
	}
	
	/**
	 * Legt ein neues Objekt vom Typ Rennen an.
	 */
	public Rennen rennenAnlegen(Scanner scanner){
		String fahrername = Rennauto.eingabeEinlesenString(scanner, "Bitte geben Sie den Fahrernamen an.");
		String fahrzeugtyp = Rennauto.eingabeEinlesenString(scanner, "Bitte geben Sie den Fahrzeugtypen an.");
		double maximalgeschwindigkeit = Rennauto.eingabeEinlesenDouble(scanner, "Bitte geben Sie die Maximalgeschwindigkeit an.");
		return new Rennen(fahrername, fahrzeugtyp, maximalgeschwindigkeit);
	}

	/**
	 * F�gt ein neues Objekt dem Array Rennautos hinzu und erweitert, wenn n�tig, das Array.
	 */
	public void addRennauto(Scanner scanner) {
		if (anzahlAutos >= rennautos.length) {
			Rennauto[] kopieKasten = new Rennauto[anzahlAutos];
			System.arraycopy(rennautos, 0, kopieKasten, 0, rennautos.length);

			rennautos = new Rennauto[anzahlAutos * 2];
			System.arraycopy(kopieKasten, 0, rennautos, 0, kopieKasten.length);

			System.out.println("Array erweitert");
		}
		rennautos[anzahlAutos] = Rennauto.rennautoAnlegen(scanner);
		System.out.println("Sie haben erfolgreich " + rennautos[anzahlAutos].getFahrerName() + " hinzugefuegt.");
		anzahlAutos++;
		System.out.println("Es existieren nun " + anzahlAutos + " Rennautos.");
	}

	/**
	 * Gibt Informationen �ber die Objekte im Array Rennautos aus.
	 */
	public void ausgabe() {
		System.out.println("Anzahl der Autos: " + anzahlAutos);
		for (int i = 0; i < anzahlAutos; i++) {
			System.out.println("Fahrer " + (i + 1) + ": " + rennautos[i].getFahrerName() + " im Auto: " + rennautos[i]);
		}
	}

	/**
	 * F�hrt einen Zeitschritt f�r alle Objekte im Array Rennautos durch.
	 */
	public void schritt() {
		for (int i = 0; i < anzahlAutos; i++) {
			rennautos[i].fahren();
		}
		System.out.println();
	}

	/**
	 * Gibt, wenn vorhanden, das Objekt aus, welches das Rennen gewonnen hat.
	 */
	public Rennauto ermittleSieger() {
		for (int i = 0; i < anzahlAutos; i++) {
			if (rennautos[i].getGefahreneStrecke() >= streckenlaenge) {
				return rennautos[i];
			}
		}
		return new Rennauto();
	}
	
	/**
	 * Setzt die gefahrenen Strecke der einzelnen Objekte im Array Rennautos zur�ck.
	 */
	public void zuruecksetzen(){
		for (int i = 0; i < anzahlAutos; i++){
			rennautos[i].setGefahreneStrecke(0);
		}
	}
	
	/**
	 * F�hrt ein komplettes Rennen durch, inklusive Ermittlung des Siegers.
	 */
	public void durchfuehren() {
		double maximalGefahreneStrecke = 0;
		zuruecksetzen();
		while (true) {
			schritt();
			for (int i = 0; i < anzahlAutos; i++) {
				if (rennautos[i].getGefahreneStrecke() > maximalGefahreneStrecke) {
					maximalGefahreneStrecke = rennautos[i].getGefahreneStrecke();
				}
			}
			if (maximalGefahreneStrecke > streckenlaenge){
				break;
			}
		}
		sieger = ermittleSieger();
		System.out.println("Der Gewinner ist: " + sieger);

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Rennen rennen = new Rennen();
		rennen.rennenAnlegen(scanner);

		int index = 0;
		while (index != 9) {
			System.out.println("Bitte waehlen Sie:\n");
			System.out.println("1: Rennen fahren");
			System.out.println("2: Auto hinzuf�gen");
			System.out.println("3: Autos anzeigen");
			System.out.println("4: Schritt fahren");
			System.out.println("5: Sieger ermitteln");
			System.out.println("9: Ende");
			index = scanner.nextInt();
			System.out.println();

			switch (index) {
			case 1:		//Rennen fahren
				rennen.setStreckenlaenge(scanner);
				rennen.durchfuehren();
				break;

			case 2:		//Auto hinzufuegen
				rennen.addRennauto(scanner);
				break;

			case 3:		//Autos anzeigen
				rennen.ausgabe();
				break;
				
			case 4:		//Schritt fahren
				rennen.schritt();
				break;
			
			case 5:		//Sieger ermitteln
				rennen.setStreckenlaenge(scanner);
				Rennauto sieger = rennen.ermittleSieger();
				System.out.println("Der Gewinner ist: " + sieger);
				break;

			case 9:		//Ende
				System.out.println("Ende");
				break;

			default:
				System.out.println("Falsche Auswahl");
				break;
			}// switch
		} // while
		scanner.close();
	}//main
}//class
