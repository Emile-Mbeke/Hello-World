/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 4, Aufgabe 1
* Verwendete Quellen:--
*/

package aufgabenblatt4;

import java.util.Scanner;
/**
 * Ein Rennauto beinhaltet die Informationen ueber den Fahrer, den Fahrzeugtypen, die Maximalgeschwindigkeit
 * sowie ueber die bisher gefahrene Strecke.
 *  
 * @author Andre Brand
 *
 */
public class Rennauto {
	private String fahrerName;
	private String fahrzeugTyp;
	private double maximalGeschwindigkeit;
	private double gefahreneStrecke;
	
	public Rennauto(){
	}
	
	public Rennauto(String fahrername, String fahrzeugtyp, double maximalgeschwindigkeit) {
		this.fahrerName = fahrername;
		this.fahrzeugTyp = fahrzeugtyp;
		this.maximalGeschwindigkeit = maximalgeschwindigkeit;
	}
	
	public String toString() {
		return fahrerName;
	}
	
	public double getGefahreneStrecke(){
		return this.gefahreneStrecke;
	}
	
	public String getFahrerName(){
		return this.fahrerName;
	}
	
	public void setGefahreneStrecke(double gefahreneStrecke){
		this.gefahreneStrecke = gefahreneStrecke;
	}
		
	public static String eingabeEinlesenString(Scanner scanner, String ausgabe){
		System.out.println(ausgabe);
		String eingabe = scanner.next();
		return eingabe;
	}
	
	public static double eingabeEinlesenDouble(Scanner scanner, String ausgabe){
		System.out.println(ausgabe);
		double eingabe = scanner.nextDouble();
		return eingabe;
	}
	
	/**
	 * Legt ein neues Objekt vom Typ Rennauto an.
	 */
	public static Rennauto rennautoAnlegen(Scanner scanner){
		String fahrername = Rennauto.eingabeEinlesenString(scanner, "Bitte geben Sie den Fahrernamen an.");
		String fahrzeugtyp = Rennauto.eingabeEinlesenString(scanner, "Bitte geben Sie den Fahrzeugtypen an.");
		double maximalgeschwindigkeit = Rennauto.eingabeEinlesenDouble(scanner, "Bitte geben Sie die Maximalgeschwindigkeit an.");
		return new Rennauto(fahrername, fahrzeugtyp, maximalgeschwindigkeit);
	}

	/**
	 * Bewegt das Rennauto einen Zeitschritt vorwaerts.
	 */
	public void fahren() {
		final int minutenProStunde = 60;
		double randomGeschwindigkeit = Math.random() * maximalGeschwindigkeit;
		if (gefahreneStrecke <= 0) {
			gefahreneStrecke = maximalGeschwindigkeit / minutenProStunde;
			ausgeben(maximalGeschwindigkeit, gefahreneStrecke);
		} else {
			gefahreneStrecke += randomGeschwindigkeit / minutenProStunde;
			ausgeben(randomGeschwindigkeit, gefahreneStrecke);
		}
	}

	/**
	 * Gibt die Informationen ueber das Rennautos aus.
	 */
	public void ausgeben(double randomGeschwindigkeit, double gefahreneStrecke) {
		System.out.format(fahrerName + " hat mit ihrem " + fahrzeugTyp + " nun %.2f km zur�ckgelegt. ", gefahreneStrecke);
		System.out.format("Geschwindigkeit: %.2f\n", randomGeschwindigkeit);
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int index = 1;

		Rennauto auto = Rennauto.rennautoAnlegen(scanner);

		while (index != 3) {
			System.out.println("Bitte waehlen Sie Ihre naechste Aktion.");
			System.out.println("1: Fahren");
			System.out.println("2: Ende");
			index = scanner.nextInt();

			switch (index) {
			case 1:
				while (true) {
					System.out.println("Moechten Sie einen Schritt fahren?");
					System.out.println("1: Ja");
					System.out.println("2: Nein");
					int indexWhile = scanner.nextInt();
					if (indexWhile == 1) {
						auto.fahren();
					} else if (indexWhile == 2) {
						break;
					} else {
						System.out.println("Falsche Auswahl");
					}
				}
				break;

			case 2:
				System.out.println("Ende");
				break;

			default:
				System.out.println("Falsche Auswahl!");
				break;
			}
		} // while
		scanner.close();
	}// main
}// class