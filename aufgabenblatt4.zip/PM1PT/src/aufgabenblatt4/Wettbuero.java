/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 4, Aufgabe 3
* Verwendete Quellen:--
*/

package aufgabenblatt4;

import java.util.Scanner;


/**
 * Ein Wettbuero fuehrt ein Rennen durch, wertet dies aus und prueft, ob Wetten gewonnen wurden.
 * 
 * @author Andre
 *
 */
public class Wettbuero {
	
	/**
	 * Faktor, um den sich der Wetteinsatz bei Gewinn erhoeht.
	 */
	private int faktor;
	
	/**
	 * Anzahl der Wetten.
	 */
	private int anzahlWetten;
	
	/**
	 * Array, welches die Objekte vom Typ Wette enthaelt.
	 */
	private Wette wettenListe[];
	
	/**
	 * Gewinner der Wette
	 */
	private Wette gewinner;
	
	/**
	 * Rennen, welches hier durchgefuehrt wird.
	 */
	private static Rennen rennen;

	/**
	 * Fuegt dem Wettbuero eine neue Wette hinzu.
	 */
	public void wetteHinzufuegen(Scanner scanner) {
		
		//Prueft, ob bereits ein Sieger des Rennens vorhanden ist.
		if (rennen.sieger != null){
			System.out.println("Es kann keine Wette mehr angelegt werden.");
		} else {
			
			//Erstellt ein neues Array vom Typ Wette, sofern noch keines vorhanden ist.
			if (anzahlWetten <= 0){
			wettenListe = new Wette[1];
			
			} else if (anzahlWetten >= wettenListe.length) {
				
				//Erweitert das Array vom Typ Wette, sofern dies noetig ist.
				Wette[] kopieKasten = new Wette[anzahlWetten];
				System.arraycopy(wettenListe, 0, kopieKasten, 0, wettenListe.length);

				wettenListe = new Wette[anzahlWetten * 2];
				System.arraycopy(kopieKasten, 0, wettenListe, 0, kopieKasten.length);

				System.out.println("Array erweitert");
			}
			//Fuegt eine neue Wette zum Array hinzu.
			wettenListe[anzahlWetten].wetteAnlegen(scanner);
			anzahlWetten++;
		}
	}

	/**
	 * Prueft, ob eine Wette gewonnen hat.
	 */
	public boolean wettePruefen() {
		//Prueft, ob eine Wette vorhanden ist.
		if (rennen.sieger != null){
			if (wettenListe != null){
				for (int i = 0; i < anzahlWetten; i++) {
					//Prueft, ob eine Wette gewonnen wurde und gibt die Wett-Sieger aus
					if (wettenListe[i].getFahrername().equals(rennen.sieger.getFahrerName())) {
						gewinner = wettenListe[i];
						gewinnAusschuetten();
					} else{
						System.out.println(wettenListe[i].getSpieler() + " hat nicht gewonnen.\n");
					}
				}
				return true;
			} else {
				System.out.println("Keine Wette vorhanden.\n");
				return false;
			}
		}else{
			System.out.println("Das Rennen ist noch nicht vorbei.\n");
			return false;
		}
	}

	/**
	 * Berechnet den Gewinn einer Wette.
	 */
	public void gewinnAusschuetten() {
		//Festlegen des Faktors anhand der Anzahl der Rennautos, sowie Berechnung des Gewinns.
		double gewinn = 0;
		faktor = rennen.getAnzahlAutos();
		if (gewinner.getFahrername().equals(rennen.sieger.getFahrerName())){
			gewinn = faktor * gewinner.getWetteinsatz();
			System.out.format(gewinner + " hat %.2f Euro gewonnen.\n\n", gewinn);
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		rennen = new Rennen();
		rennen.rennenAnlegen(scanner);
		Wettbuero wettbuero = new Wettbuero();

		int index = 0;
		while (index != 9) {
			System.out.println("Bitte waehlen Sie:\n");
			System.out.println("1: Wette hinzufuegen");
			System.out.println("2: Auto hinzufuegen");
			System.out.println("3: Autos anzeigen");
			System.out.println("4: Rennen fahren");
			System.out.println("5: Wetten auswerten");
			System.out.println("9: Ende");
			index = scanner.nextInt();
			System.out.println();

			switch (index) {
			case 1: // Wette hinzufuegen
				wettbuero.wetteHinzufuegen(scanner);
				break;

			case 2: // Auto hinzufuegen
				rennen.addRennauto(scanner);
				break;

			case 3: // Autos anzeigen
				rennen.ausgabe();
				break;

			case 4: // Rennen fahren
				rennen.setStreckenlaenge(scanner);
				rennen.durchfuehren();
				break;

			case 5: // Wetten auswerten
				boolean wetteVorhanden = wettbuero.wettePruefen();
				if(wetteVorhanden){
					index = 9;
				}
				break;

			case 9: // Ende
				System.out.println("Ende");
				break;

			default:
				System.out.println("Falsche Auswahl");
				break;
			}// switch
		} // while
		scanner.close();
	}//main
}//class
