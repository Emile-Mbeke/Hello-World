/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 4, Aufgabe 3
* Verwendete Quellen: --
*/

package aufgabenblatt4;

import java.util.Scanner;

/**
 * Eine Wette enthaelt Informationen ueber den Namen der Person, die gewettet hat,
 * den Namen der Fahrerin, auf die gewettet wurde, sowie den Einsatz der Wette.
 * 
 * @author Andre
 *
 */
public class Wette {
	
	/**
	 * Name des Fahrers
	 */
	private String fahrername;
	
	/**
	 * Name des Spielers
	 */
	private String spieler;
	
	/**
	 * Wetteinsatz
	 */
	private double wetteinsatz;
	
	public Wette(){
		
	}
	
	public Wette(String fahrername, double wetteinsatz, String spieler){
		this.fahrername = fahrername;
		this.spieler = spieler;
		this.wetteinsatz = wetteinsatz;
	}
	
	public String toString(){
		return spieler;
	}
	
	public String getFahrername(){
		return fahrername;
	}
	
	public String getSpieler(){
		return spieler;
	}
	
	public double getWetteinsatz(){
		return wetteinsatz;
	}
	
	/**
	 * Legt ein neues Objekt vom Typ Wette an.
	 */
	public Wette wetteAnlegen(Scanner scanner){
		String fahrername = Rennauto.eingabeEinlesenString(scanner, "Auf welche Fahrerin moechten Sie wetten?");
		String spieler = Rennauto.eingabeEinlesenString(scanner, "Wie lautet ihr Name?");
		double wetteinsatz = Rennauto.eingabeEinlesenDouble(scanner, "Wie hoch soll Ihr Wetteinsatz sein?");
		return new Wette(fahrername, wetteinsatz, spieler);
	}
	
}
