/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 5, Aufgabe 2
* Verwendete Quellen:--
*/

package aufgabenblatt5;

/**
 * Ein Eisenbahnzug besteht aus einer Lokomotive, an die Wagen hintereinander angehaengt werden koennen.
 * 
 * @author Andre
 *
 */
public class Eisenbahnzug {
	private Lokomotive lok;

	public Eisenbahnzug(int laenge, int typ) {
		lok = new Lokomotive(laenge, typ);
	}
	
	public int getWagenAnzahl() {
		int anzahlWagen = 0;
		Wagen aktuellerWagen = lok.getWagen();
		while (aktuellerWagen != null) {
			anzahlWagen++;
			aktuellerWagen = aktuellerWagen.getWagen();
		}
		return anzahlWagen;
	}

	public int getKapazitaet() {
		int kapazitaet = 0;
		Wagen aktuellerWagen = lok.getWagen();
		while (aktuellerWagen != null) {
			kapazitaet += aktuellerWagen.getPassagierKapazitaet();
			aktuellerWagen = aktuellerWagen.getWagen();
		}
		return kapazitaet;
	}

	public int getLaenge() {
		int laenge = lok.getLaenge();
		Wagen aktuellerWagen = lok.getWagen();
		while (aktuellerWagen != null) {
			laenge += aktuellerWagen.getLaenge();
			aktuellerWagen = aktuellerWagen.getWagen();
		}
		return laenge;
	}

	public String toString() {
		String string = lok.toString();
		string += String.format(
				" Laenge des Zuges: %d Meter \n Anzahl der Wagen: %d Wagen \n Passagierkapazitaet: %d Personen \n",
				this.getLaenge(), this.getWagenAnzahl(), this.getKapazitaet());
		;
		int zahlWagen = 0;
		Wagen aktuellerWagen = lok.getWagen();
		while (aktuellerWagen != null) {
			zahlWagen++;
			string += String.format(" Wagen %d\n", zahlWagen);
			string += aktuellerWagen.toString();
			aktuellerWagen = aktuellerWagen.getWagen();
		}
		return string;
	}

	/**
	 * Haengt an den Zug einen weiteren Wagen hinten an.
	 * 
	 * @param wagen	Wagen, der an den Zug angehaengt werden soll.
	 */
	public void wagenHinzufuegen(Wagen wagen) {
		if (lok.getWagen() == null) {
			lok.setWagen(wagen);
		} else {
			lok.getWagen().setWagen(wagen);
		}
	}

	/**
	 * Koppelt den ersten Wagen, der direkt an der Lok haengt, ab und haengt den
	 * Wagen, welcher an diesem abgekoppelten Wagen hing, wieder an die Lok an.
	 * 
	 * @return	Abgekoppelter Wagen
	 */
	public Wagen ersterWagenEntfernen() {
		Wagen entfernterWagen = lok.getWagen();
		lok.setWagen(lok.getWagen().getWagen());
		entfernterWagen.abkoppeln();
		return entfernterWagen;
	}

	/**
	 * Koppelt alle Wagen eines Zuges ab und haengt diese an einen anderen Zug wieder an.
	 * 
	 * @param anderer	Zug, von dem die Wagen abgehaengt werden sollen.
	 */
	public void zugAnhaengen(Eisenbahnzug anderer) {
		while(anderer.lok.getWagen() != null){
			this.wagenHinzufuegen(anderer.ersterWagenEntfernen());
		}
	}


	public static void main(String[] args) {
		Eisenbahnzug zug1 = new Eisenbahnzug(30, 123);
		Eisenbahnzug zug2 = new Eisenbahnzug(35, 122);

		zug1.wagenHinzufuegen(new Wagen(25, 50));
		zug1.wagenHinzufuegen(new Wagen(25, 50));
		zug1.wagenHinzufuegen(new Wagen(25, 50));
		zug1.wagenHinzufuegen(new Wagen(25, 50));

		System.out.println(zug1);

		System.out.println(" Entfernt: " + zug1.ersterWagenEntfernen());
		System.out.println();

		System.out.println(zug1);

		zug2.wagenHinzufuegen(new Wagen(30, 50));
		zug2.wagenHinzufuegen(new Wagen(30, 50));
		zug2.wagenHinzufuegen(new Wagen(30, 50));
		zug2.wagenHinzufuegen(new Wagen(30, 50));

		System.out.println(zug2);

		System.out.println(" Entfernt: " + zug2.ersterWagenEntfernen());
		System.out.println();

		System.out.println(zug2);

		zug1.zugAnhaengen(zug2);

		System.out.println(zug1);
		System.out.println(zug2);
	}
}
