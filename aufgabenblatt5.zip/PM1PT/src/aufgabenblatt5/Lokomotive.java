/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 5, Aufgabe 2
* Verwendete Quellen:--
*/

package aufgabenblatt5;

/**
 * Die Klasse Lokomotive stellt ein Objekt dar, welches in der Klasse
 * Eisenbahnzug als Hauptobjekt genutzt wird und an dem Wagen angehaengen werden
 * koennen.
 * 
 * @author Andre
 *
 */
public class Lokomotive {
	/**
	 * Laenge der Lokomotive in Metern.
	 */
	private final int laenge;
	
	/**
	 * Typ der Lokomotive
	 */
	private final int typ;
	
	/**
	 * Wagen, der direkt an die Lokomotive gehaengt wurde.
	 */
	private Wagen ersterWagen;

	public Lokomotive(int laenge, int typ, Wagen wagen){
		this.laenge = laenge;
		this.typ = typ;
		ersterWagen = wagen;
	}

	public Lokomotive(int laenge, int typ) {
		this(laenge, typ, null);
	}

	public int getLaenge() {
		return laenge;
	}

	public int getTyp() {
		return typ;
	}

	public Wagen getWagen() {
		return ersterWagen;
	}

	public void setWagen(Wagen wagen) {
		ersterWagen = wagen;
	}
	
	public String toString() {
		String string = String.format(" Typ der Lokomotive: %d \n Laenge: %d \n ", typ, laenge);
		return string;
	}
}
