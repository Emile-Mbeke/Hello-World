/**
* Praktikum TI PT, SS 2016
* Gruppe: Andre Brand (andre.brand@haw-hamburg.de),
* Essam Mbeke, Emile
* Aufgabe: Aufgabenblatt 5, Aufgabe 2
* Verwendete Quellen:--
*/

package aufgabenblatt5;

/**
 * Die Klasse Wagen stellt Objekte dar, die an eine Lokomotive oder an einen
 * anderen Wagen gehaengt werden koennen.
 * 
 * @author Andre
 *
 */
public class Wagen {
	/**
	 * Seriennummer der Wagen.
	 */
	private static int seriennummer = 0;

	/**
	 * Laenge eines Wagens in Metern.
	 */
	private final int laenge;

	/**
	 * Anzahl der maximalen Personen, welche in einem Wagen Platz finden.
	 */
	private final int passagierkapazitaet;

	/**
	 * Stellt die Seriennummer eines einzelnen Wagens dar.
	 */
	private final int zaehlerSeriennummer;

	/**
	 * Ein Wagen, welcher an dem aktuellen Objekt Wagen angehaengt wurde.
	 */
	private Wagen naechsterWagen;

	public Wagen(int laenge, int kapazitaet, Wagen wagen) {
		this.laenge = laenge;
		this.passagierkapazitaet = kapazitaet;
		naechsterWagen = wagen;
		zaehlerSeriennummer = ++seriennummer;
	}

	public Wagen(int laenge, int kapazitaet) {
		this(laenge, kapazitaet, null);
	}

	public int getLaenge() {
		return laenge;
	}

	public int getPassagierKapazitaet() {
		return passagierkapazitaet;
	}

	public Wagen getWagen() {
		return naechsterWagen;
	}

	public void setWagen(Wagen wagen) {
		if (naechsterWagen == null) {
			naechsterWagen = wagen;
		} 
		else {
			naechsterWagen.setWagen(wagen);
		}
	}

	public String toString() {
		String string = String.format(" Wagenlaenge: %d Seriennummer: %d\n", laenge, zaehlerSeriennummer);
		return string;
	}

	/**
	 * Entfernt den angehaengten Wagen.
	 */
	public void abkoppeln() {
		naechsterWagen = null;
	}
}
